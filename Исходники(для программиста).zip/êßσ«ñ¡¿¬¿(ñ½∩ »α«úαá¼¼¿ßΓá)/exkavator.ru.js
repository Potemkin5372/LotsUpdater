"use strict";
//setTimeout('console.log("suka")',1000);
var inProgress=false;
var isLotsOpened=false;
var externIndex=0;
var externElems = new Array();
var externUpdateLeft = new Array();
var externUpdateLeftForPrevLot;
var page = require('webpage').create();
var system = require('system');   
//window.logi=system.args[1];
var login=system.args[1];
var password=system.args[2];
var log_json=JSON.stringify(login+" "+password);
var notAllWasUpdated=false;
//var pass_json=JSON.stringify(password);
//page.evaluate("function() {document.body.innerHTML = '" + size + uid + "'}");

//var page = require('webpage').create();
var isLogined=false;
var countOfLogingTryes=0;
var countOfOpenPageTryes=0;
var countOfUpdatingTryes=0;
page.onConsoleMessage = function(msg) {
  console.log(msg);
}
page.onLoadStarted = function() {
  inProgress = true;
  //exeFuncCount++;
  console.log("started...");  
};

page.onLoadFinished = function() {
  inProgress = false;
  //exeFuncCount--;
  console.log("finished...");
};
page.injectJs('jquery.js');
/*page.evaluate("function() {
	console.log('"+logi+"');
}");*/
//пытаюсь залогинится
setInterval(function(){
	if(!isLogined){
		if(countOfLogingTryes<15){
			page.open('http://exkavator.ru/trade/auth/login.html'+'?'+encodeURIComponent(log_json), function(status2) {
			//page.includeJs("http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js", function() {		
				if(status2==="success"){
					//page.injectJs('incl.js');						
					isLogined=true;
				    page.evaluate(function() {
				    	var log_json=decodeURIComponent(window.location.search.substring(1));
				    	var str=eval('('+log_json+')');
				    	var login=str.substring(0,str.indexOf(" "));
				    	var password=str.substring(str.indexOf(" ")+1,str.length);
				    	//console.log(login+"    "+password);
				    	$("form[action='http://exkavator.ru/trade/auth/login.html'] #username").val(login)
				       //$("#username").text("infoboss@yandex.ru");
			       		$("form[action='http://exkavator.ru/trade/auth/login.html'] #password").val(password);
			       		//page.render('N:/Tasks//Задание3//screen.png');			
			       		$("form[action='http://exkavator.ru/trade/auth/login.html']").submit();         		     	
			       		//setTimeout(function(){

				       	//document.location = "http://exkavator.ru/trade/companymanager/show_lots.html"	              		
				    });		 	    
				    setInterval(function(){
				    	if(!inProgress){
				    		if(!isLotsOpened){
				    			if(countOfOpenPageTryes<15){
					    			page.open('http://exkavator.ru/trade/companymanager/show_lots.html',function(status){
					    				if(status==="success"){
					    					console.log("страница открыта");
					    					externElems=page.evaluate(function() {		  
					    						window.elems = new Array();  					
												$(".lot_reload").each(function () {
													window.elems.push(this.id);									
												});			
												return window.elems;			    					    					
						    				});
						    				externUpdateLeft=page.evaluate(function() {		  
						    					window.updateLeft = new Array();	
						    					window.lot_index=0;				
												$('span.qtipel-up').each(function () {
													window.updateLeft.push(this.innerHTML);														
												});
												return window.updateLeft;
											});
						    				if(externElems.length!=0){
												isLotsOpened=true;							    				
											}else{												
												console.log("не могу авторизироваться...");	
												console.log("2");
												phantom.exit();		
											}
					    				}else{
					    					countOfOpenPageTryes++;
					    					console.log("не могу открыть страницу...");
					    				}
					    			});
					    		}else{
					    			//page.render(pathForScreen);
					    			console.log("3");
									phantom.exit();		 
					    		}
				    		}else{	
				    			if(externIndex>0){
				    				externUpdateLeftForPrevLot=page.evaluate(function() {		  
						    			//window.updateLeft = new Array();	
						    			//window.lot_index=0;				
						    			var str='.alc.date.counter_'+ window.elems[window.lot_index-1];
						    			console.log("Previous lot is "+window.elems[window.lot_index-1]);
						    			var change;
										$(str).find('span').each(function () {
											change=this.innerHTML;														
										});
				    					//change=$(str).innerHTML;
										return change;
									});													
				    			}   
				    			//console.log("externUpdateLeftForPrevLot= "+externUpdateLeftForPrevLot+" externUpdateLeft="+externUpdateLeft[externIndex-1]+" externIndex="+externIndex);								    			
				    			if(externIndex>0 && externUpdateLeftForPrevLot==externUpdateLeft[externIndex-1] && countOfUpdatingTryes<1){
				    				externIndex=page.evaluate(function() {					    									    					
				    					//$('#'+window.elems[window.lot_index]).click();					    	
				    					//console.log("хуйня нездоровая");
				    					console.log("this lot wat not updated: "+window.elems[window.lot_index-1]);				    					
										//console.log('#'+window.elems[window.lot_index-1]);											    										    
										return window.lot_index;																    		
								    });								    
								    countOfUpdatingTryes++;
								    if(countOfUpdatingTryes>=1){
								    	notAllWasUpdated=true;
								    }
				    			}else{
				    				countOfUpdatingTryes=0;
				    				if(externIndex<externElems.length){	    				
					    				externIndex=page.evaluate(function() {	
					    					while(window.updateLeft[window.lot_index]=='0'){
					    						window.lot_index++;
					    					}	
					    					if(window.updateLeft[window.lot_index]!='0'){
					    						//$('#'+window.elems[window.lot_index]).click();					    	
												console.log('#'+window.elems[window.lot_index]);							
					    					}					    	
											return ++window.lot_index;																    		
									    });	    				    			
					    			}else{				    				
								    	console.log('screen_updated'); 
								    	//page.render(pathForScreen); 
								    	if(notAllWasUpdated){
								    		console.log('4');  	
								    	}else{
								    		console.log('0'); 
								    	}									    	
								    	phantom.exit();		    	   
					    			}
				    			}				    						    						
				    		}	
				    			    			    		    
				    	}	    	
				    },2500);	    	    
				}else{
					console.log("Can't login");
					countOfLogingTryes++;
				} 	
			});
		}else{
			//page.render(pathForScreen);
			console.log("1");
			phantom.exit();		    	   
		}
	}
},5000);
