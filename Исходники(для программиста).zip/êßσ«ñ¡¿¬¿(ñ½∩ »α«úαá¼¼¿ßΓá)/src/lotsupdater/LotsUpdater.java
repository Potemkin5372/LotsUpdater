﻿/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lotsupdater;

import java.awt.Color;
import static java.awt.Component.LEFT_ALIGNMENT;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import java.util.Date;
import java.util.EventListener;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
/**
 *
 * @author Potemkin
 */
public class LotsUpdater {

    /**
     * @param args the command line arguments
     */
    public static ArrayList<Table> arrOfTables;
    public static String currProjPath;
    public static Settings settings;
    public static ArrayList<String> arrOfVisitedToday;
    public static String currDate;
    public static HashMap<String,boolean[]> updatedLots; 
    public static TrayIcon trayIcon;
    public static MenuFrame frame;
    public static void main(String[] args) {
        // TODO code application logic here
        if(args.length!=0){
            initProjFirstTime(args[0]);        
        }else{
            initProjFirstTime("");        
        }        
        frame=mainFrameInit();                
        if(settings.isRunnued){
            //Начинаю работать
           startUpdating();                       
        }                
        
    }   
    static void changeTrayIcon(String iconPath){
        Image icon = Toolkit.getDefaultToolkit().getImage(iconPath);
        frame.setIconImage(new ImageIcon(iconPath).getImage());
        //TrayIcon trayIcon = new TrayIcon(icon, "LotsUpdater", trayMenu); 
        trayIcon.setImage(icon);
    }
    private static TrayIcon setTrayMenu(JFrame frame, String iconPath) {
        if(! SystemTray.isSupported() ) {
          return null;
        }

        PopupMenu trayMenu = new PopupMenu();       
        MenuItem itemExit = new MenuItem("Exit");
        itemExit.addActionListener(new ActionListener() {          
          public void actionPerformed(ActionEvent e) {
            settings.saveSettings();
            System.exit(0);
          }
        });
        trayMenu.add(itemExit);
        MenuItem itemShow = new MenuItem("Показать таблицы");
        itemShow.addActionListener(new ActionListener() {          
          public void actionPerformed(ActionEvent e) {            
            settings.isWindowVisible=true;
            frame.setVisible(true);
          }
        });               
        trayMenu.add(itemShow);
        trayMenu.add(itemExit);   
        
        //URL imageURL = TestFrame.class.getResource(ICON_STR);

        Image icon = Toolkit.getDefaultToolkit().getImage(iconPath);
        TrayIcon trayIcon = new TrayIcon(icon, "LotsUpdater", trayMenu);        
        trayIcon.setImageAutoSize(true);
        trayIcon.addMouseListener(new MouseAdapter(){
            public void mouseClicked(MouseEvent evt){
                if(evt.getClickCount()==2){
                    settings.isWindowVisible=true;
                    frame.setVisible(true);
                }
            }
        });
        SystemTray tray = SystemTray.getSystemTray();          
        try {         
          tray.add(trayIcon);
        } catch (Exception e) {
          e.printStackTrace();
        }
        return trayIcon;
        //trayIcon.displayMessage(APPLICATION_NAME, "Application started!",TrayIcon.MessageType.INFO);
    }
    public static void startUpdating(){
        updateEveryDay();
        //Прямо в этот момент запускаю обновления
        Timer firstTimer=new Timer();
        firstTimer.schedule(new Task(), 0); 
        
        Date date=new Date();
        if(date.getHours()<23){
            date.setHours(date.getHours()+1);   
            date.setMinutes(0);
            date.setSeconds(0);
            //Дата установлена на 1 час позже текущего времени. И далее это задание будет выполняться через каждый час, а в 23 00 выполнится последний раз
            Timer constantTimer=new Timer();
            constantTimer.schedule(new Task(), date, 3600*1000);
        }                                  
        Timer newDay=new Timer(); 
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE,1);
        Date newDayDate=new Date();
        newDayDate.setHours(0);
        newDayDate.setMinutes(0);
        newDayDate.setSeconds(0);
        newDayDate.setDate(cal.getTime().getDate());
        System.out.println("Новый день наступит "+ newDayDate.toString());
        newDay.schedule(new TimerTask(){            
            public void run() {
                System.out.println("Новый день!");
                startUpdating();
            }
            
        }, newDayDate);
    }
    public static String getProjPath(String input){
        String projPath="";        
        //Объект для чтения файла в буфер
        /*BufferedReader in=null;
        try {
            //В цикле построчно считываем файл
            in = new BufferedReader(new FileReader(System.getProperty("user.dir")+"\\LotsUpdaterPath.txt"));
            String s;
            while ((s = in.readLine()) != null) {
                projPath=s;
            }            
        }catch(Exception ex){
            
        }finally {
            try {
                //Также не забываем закрыть файл
                in.close();
            } catch (IOException ex) {
                Logger.getLogger(LotsUpdater.class.getName()).log(Level.SEVERE, null, ex);
            }
        } */
        if(input.equals("")){
            projPath=System.getProperty("user.dir");
        }else{
            projPath=input;
        }
        return projPath;
    }
    public static void initProjFirstTime(String input){        
        currProjPath=getProjPath(input);                        
        //currProjPath=System.getProperty("user.dir");
        try {  
            File file=new File(currProjPath+"\\Settings\\settings.out");
            if(file.exists()){                
                settings=Settings.loadSettings();
                //currProjPath=settings.currProjPath;
            }else{                
                settings=new Settings(); 
            }   
            file = new File(currProjPath+"\\Save\\tables.out");
            if(file.exists()){                
                loadTables();                
            }else{
                createFileOfTables();            
            }                          
        } catch (Exception ex) {   
            Logger.getLogger(LotsUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }              
    }
    public static void updateEveryDay(){
        System.out.println(currDate=getCurrDate());
        updatedLots=new HashMap();
        File file = new File(currProjPath+"\\Update\\"+currDate+".out");
        try{           
            if(file.exists()){
                updatedLots=loadUpdates(currDate+".out");
            }else{                
                for(int i=0;i<arrOfTables.size();i++){
                    updatedLots.put(arrOfTables.get(i).tableName,new boolean[24]);
                }
            }
        }catch(Exception ex){
            Logger.getLogger(LotsUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static String getCurrDate(){
        Calendar calendar = Calendar.getInstance();
        String date;
        date = ""+calendar.get(Calendar.DAY_OF_MONTH)+"."+(calendar.get(Calendar.MONTH)+1)+"."+calendar.get(Calendar.YEAR);        
        return date;
    }
    public static void mainPanelInit(JPanel panel){        
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));                
    }
    public static MenuFrame mainFrameInit(){
        MenuFrame frame=new MenuFrame();     
        mainPanelInit(frame.mainPanel);
        frame.setTitle(currProjPath);
        frame.setIconImage(new ImageIcon(LotsUpdater.currProjPath+"\\Icons\\icon3.png").getImage());
        frame.setDefaultCloseOperation(0);
        frame.addWindowListener(new WindowAdapter(){
            public void windowClosing(WindowEvent e) {   
                //System.out.println("[eq");
                settings.isWindowVisible=false;
                frame.setVisible(false);
                settings.saveSettings();
            }
        }); 
        for(int i=0;i<arrOfTables.size();i++){
            frame.mainPanel.add(new DrawTable(arrOfTables.get(i)));                              
        }   
        //MenuFrame.checkAutorun.setSelected(settings.isAutorun);
        settings.settingsChanged();
        frame.setBounds(0, 100, 800, 600);
        frame.setVisible(settings.isWindowVisible);
        frame.revalidate(); 
        trayIcon=setTrayMenu(frame,currProjPath+"\\Icons\\icon3.png");
        //setTrayIcon(frame,currProjPath+"\\Icons\\icon3.png");
        return frame;
    }
    public static void createFileOfTables(){
        arrOfTables=new ArrayList();
        arrOfTables.add(new Table("exkavator.ru","infoboss@yandex.ru","111111"));
        arrOfTables.add(new Table("trucks.dmir.ru","infoboss@yandex.ru","111111"));
        arrOfTables.add(new Table("flagma.ru","infoboss@yandex.ru","111111"));
        arrOfTables.add(new Table("gruzovoy.ru","infoboss@yandex.ru","111111"));
        arrOfTables.add(new Table("acoola.ru","infoboss@yandex.ru","111111"));
    }
    public static void saveUpdates(String name){        
        FileOutputStream fos=null;        
        ObjectOutputStream oos=null;
        try {
            fos = new FileOutputStream(currProjPath+"\\Update\\"+name);
            oos= new ObjectOutputStream(fos);
            oos.writeObject(updatedLots);        
        } catch (Exception ex) {
            Logger.getLogger(LotsUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                oos.flush();
                oos.close();
                fos.close();
            } catch (IOException ex) {
                Logger.getLogger(LotsUpdater.class.getName()).log(Level.SEVERE, null, ex);
            }            
        }         
        //TestSerial ts = new TestSerial();                
    }
    public static HashMap<String,boolean[]>loadUpdates(String name){
        HashMap<String,boolean[]> map=new HashMap();
        //arrOfTables=new ArrayList();
        
        FileInputStream fis=null;
        ObjectInputStream oin=null;
        try {
            fis = new FileInputStream(currProjPath+"\\Update\\"+name);
            oin = new ObjectInputStream(fis);
            map = (HashMap<String,boolean[]>) oin.readObject();        
        } catch (Exception ex) {
            Logger.getLogger(LotsUpdater.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                fis.close();
                oin.close();
            } catch (IOException ex) {
                Logger.getLogger(LotsUpdater.class.getName()).log(Level.SEVERE, null, ex);
            }            
        }        
        return map;
    }
    public static void saveTables() throws FileNotFoundException, IOException{
        FileOutputStream fos = new FileOutputStream(currProjPath+"\\Save\\tables.out");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        //TestSerial ts = new TestSerial();        
        oos.writeObject(arrOfTables);
        oos.flush();
        oos.close();
        fos.close();
    }
    public static void loadTables() throws FileNotFoundException, IOException, ClassNotFoundException{
        arrOfTables=new ArrayList();
        FileInputStream fis = new FileInputStream(currProjPath+"\\Save\\tables.out");
        ObjectInputStream oin = new ObjectInputStream(fis);
        arrOfTables = (ArrayList<Table>) oin.readObject();
        fis.close();
        oin.close();
    }
}
class Task extends TimerTask{   
    //-------------------------------ЗАКОМЕНТИЛ В НОВОЙ ВЕРСИИ------------------------
    //static Runtime rt;
    //static Process proc;
    
    BlockingQueue sharedQueue=new LinkedBlockingQueue();
    
    public void run() {
        //System.out.println("NOOOOOOOOOOOOOOOW!!!!!!!!!"+new Date().toString());              
        Date date=new Date();          
        String day=new SimpleDateFormat ("EEE" ).format(date);
        System.out.println(day);
        for(int i=0;i<LotsUpdater.arrOfTables.size();i++){          
            if(LotsUpdater.settings.isRunnued){                
                /*System.out.println(LotsUpdater.arrOfTables.get(i).tableName);                
                if(LotsUpdater.arrOfTables.get(i).table.get(day)[date.getHours()]&&
                        !LotsUpdater.updatedLots.get(LotsUpdater.arrOfTables.get(i).tableName)[date.getHours()]){
                            try{
                                LotsUpdater.settings.status="status:    обновляю "+LotsUpdater.arrOfTables.get(i).tableName+"...";
                                LotsUpdater.settings.settingsChanged();
                                //MenuFrame.btnStop.setEnabled(false);
                                //System.out.println(LotsUpdater.currProjPath);
                                rt = Runtime.getRuntime();   
                                proc = rt.exec(LotsUpdater.currProjPath+"\\Scripts\\phantomjs-2.1.1-windows\\phantomjs-2.1.1-windows\\phantomjs "
                                        + LotsUpdater.currProjPath+"\\Scripts\\"+LotsUpdater.arrOfTables.get(i).tableName+".js"
                                        + " "+LotsUpdater.arrOfTables.get(i).login
                                        + " "+LotsUpdater.arrOfTables.get(i).password);
                                InputStream in = proc.getInputStream();            
                                BufferedReader br = new BufferedReader(new InputStreamReader(in));
                                String l=null; 
                                String lastMsg=null;
                                while ((l=br.readLine())!=null) {            
                                    System.out.println(l);
                                    lastMsg=l;
                                }   
                                if((lastMsg.toLowerCase()).equals("0".toLowerCase())){
                                    LotsUpdater.updatedLots.get(LotsUpdater.arrOfTables.get(i).tableName)[date.getHours()]=true;
                                    LotsUpdater.saveUpdates(LotsUpdater.currDate+".out");                                    
                                }else{    
                                    String errorMsg="";
                                    if((lastMsg.toLowerCase()).equals("1".toLowerCase())){
                                        errorMsg="не удалось авторизоваться, скорее всего из-за проблем с интернетом";
                                    }
                                    if((lastMsg.toLowerCase()).equals("2".toLowerCase())){
                                        errorMsg="авторизация не удалась";
                                    }
                                    if((lastMsg.toLowerCase()).equals("3".toLowerCase())){
                                        errorMsg="не удалось получить список объявлений, скорее всего из-за проблем с интернетом";
                                    }
                                    if((lastMsg.toLowerCase()).equals("4".toLowerCase())){
                                        LotsUpdater.updatedLots.get(LotsUpdater.arrOfTables.get(i).tableName)[date.getHours()]=true;
                                        LotsUpdater.saveUpdates(LotsUpdater.currDate+".out"); 
                                        errorMsg="какое-то из объявлений не было обновлено";
                                        System.out.println("не всё обновило");
                                    }
                                    //LotsUpdater.setTrayIcon(LotsUpdater.frame,LotsUpdater.currProjPath+"\\Icons\\icon3.png");
                                    LotsUpdater.changeTrayIcon(LotsUpdater.currProjPath+"\\Icons\\icon2.png");                                    
                                    File file=new File(LotsUpdater.currProjPath+"\\Logs\\"+LotsUpdater.currDate+".txt");        
                                    System.out.println(errorMsg);
                                    try(FileWriter writer = new FileWriter(file.getAbsoluteFile(), true))
                                    {
                                       // запись всей строки
                                        //String text = "Мама мыла раму, раму мыла мама";
                                        writer.write(LotsUpdater.arrOfTables.get(i).tableName+" -- "+date.toString()+" "+errorMsg+"\r\n");                                    
                                        writer.flush();
                                        writer.close();
                                    }
                                    catch(IOException ex){             
                                        System.out.println(ex.getMessage());
                                    } 
                                }
                                if(!LotsUpdater.settings.isRunnued){
                                    MenuFrame.btnStart.setEnabled(true);
                                }
                            }catch(Exception ex){ 
                                System.out.println(ex);
                            }                                                                             
                }*/
                //-------------------------------NEW CODE----------------------------------
                if(LotsUpdater.arrOfTables.get(i).table.get(day)[date.getHours()]&&
                        !LotsUpdater.updatedLots.get(LotsUpdater.arrOfTables.get(i).tableName)[date.getHours()]){
                    sharedQueue.add(new LotInQueue(
                            LotsUpdater.currProjPath+"\\Scripts\\phantomjs-2.1.1-windows\\phantomjs-2.1.1-windows\\phantomjs "
                                        + LotsUpdater.currProjPath+"\\Scripts\\"+LotsUpdater.arrOfTables.get(i).tableName+".js"
                                        + " "+LotsUpdater.arrOfTables.get(i).login
                                        + " "+LotsUpdater.arrOfTables.get(i).password,
                            LotsUpdater.arrOfTables.get(i).tableName,
                            date)
                    );                    
                }
                //-------------------------------------------------------------------------
            }else{
                LotsUpdater.settings.status="status:    жду запуска...";
                LotsUpdater.settings.settingsChanged();
            }
        }
        //---------------------------------------NEW CODE----------------------------------        
        if(sharedQueue.size()!=0){
           ArrayList<Thread> arrOfConsumers=new ArrayList();
           for(int i=0;i<LotsUpdater.settings.consumersCount;i++){
               arrOfConsumers.add(new Thread(new LotsConsumer(sharedQueue)));
               arrOfConsumers.get(i).start();
           }
           for(int i=0;i<LotsUpdater.settings.consumersCount;i++){               
               try {
                   arrOfConsumers.get(i).join();
               } catch (InterruptedException ex) {
                   Logger.getLogger(Task.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
        }
        //---------------------------------------------------------------------------------
        if(LotsUpdater.settings.isRunnued){
            LotsUpdater.settings.status="status:    жду "+(date.getHours()+1)+":00...";
            LotsUpdater.settings.settingsChanged();
        }else{
            LotsUpdater.settings.status="status:    жду запуска...";
            LotsUpdater.settings.settingsChanged();
        }
        if(date.getHours()==23){
            System.out.println("На сегодня все задания выполнены.");
            this.cancel();
        }
    }
    
}
class LotInQueue{
    String exeStr;
    String tableName;
    Date date;
    public LotInQueue(String exeStr, String tableName, Date date){
        this.exeStr=exeStr;
        this.tableName=tableName;
        this.date=date;
    }
}
class LotsConsumer implements Runnable{
    BlockingQueue sharedQueue;
    public LotsConsumer(BlockingQueue sharedQueue){
        this.sharedQueue=sharedQueue;
    }
    public void run() {
        while(sharedQueue.size()!=0&&LotsUpdater.settings.isRunnued){            
                try{
                    LotsUpdater.settings.status="status:    обновляю... ";
                    LotsUpdater.settings.settingsChanged();
                    Runtime rt;
                    Process proc;           
                    LotInQueue currLot=(LotInQueue)sharedQueue.poll();
                    rt = Runtime.getRuntime();   
                    proc = rt.exec(currLot.exeStr);
                    InputStream in = proc.getInputStream();            
                    BufferedReader br = new BufferedReader(new InputStreamReader(in));
                    String l=null; 
                    String lastMsg=null;
                    while ((l=br.readLine())!=null) {            
                        System.out.println(l);
                        lastMsg=l;
                    }   
                    if((lastMsg.toLowerCase()).equals("0".toLowerCase())){
                        LotsUpdater.updatedLots.get(currLot.tableName)[currLot.date.getHours()]=true;
                        LotsUpdater.saveUpdates(LotsUpdater.currDate+".out");                                    
                    }else{    
                        String errorMsg="";
                        if((lastMsg.toLowerCase()).equals("1".toLowerCase())){
                            errorMsg="не удалось авторизоваться, скорее всего из-за проблем с интернетом";
                        }
                        if((lastMsg.toLowerCase()).equals("2".toLowerCase())){
                            errorMsg="авторизация не удалась";
                        }
                        if((lastMsg.toLowerCase()).equals("3".toLowerCase())){
                            errorMsg="не удалось получить список объявлений, скорее всего из-за проблем с интернетом";
                        }
                        if((lastMsg.toLowerCase()).equals("4".toLowerCase())){
                            LotsUpdater.updatedLots.get(currLot.tableName)[currLot.date.getHours()]=true;
                            LotsUpdater.saveUpdates(LotsUpdater.currDate+".out"); 
                            errorMsg="какое-то из объявлений не было обновлено";
                            System.out.println("не всё обновило");
                        }
                                    //LotsUpdater.setTrayIcon(LotsUpdater.frame,LotsUpdater.currProjPath+"\\Icons\\icon3.png");
                        LotsUpdater.changeTrayIcon(LotsUpdater.currProjPath+"\\Icons\\icon2.png");                                    
                        File file=new File(LotsUpdater.currProjPath+"\\Logs\\"+LotsUpdater.currDate+".txt");        
                        System.out.println(errorMsg);
                        try(FileWriter writer = new FileWriter(file.getAbsoluteFile(), true)){
                                       // запись всей строки
                                        //String text = "Мама мыла раму, раму мыла мама";
                            writer.write(currLot.tableName+" -- "+currLot.date.toString()+" "+errorMsg+"\r\n");                                    
                            writer.flush();
                            writer.close();
                        }catch(IOException ex){             
                            //System.out.println(ex.getMessage());
                            
                        } 
                    }
                    if(!LotsUpdater.settings.isRunnued){
                        MenuFrame.btnStart.setEnabled(true);
                    }
                }catch(Exception ex){ 
                    //System.out.println(ex);
                }               
        }
    }
    
}
class MainFrame extends JFrame{
    public JPanel panel;
    public MainFrame(String name){
        super(name);
        this.setBounds(0, 100, 800, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel=new JPanel();
        panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
        JScrollPane scroll=new JScrollPane(panel);                
        this.add(scroll);
        this.setVisible(true);        
    }
}
class Table implements Serializable{
    HashMap<String,boolean[]> table;
    String tableName;
    String login;
    String password;
    Table(String tableName, String login, String password){
        this.table=createTable();
        this.tableName=tableName;
        this.login=login;
        this.password=password;
    }
    public static HashMap<String,boolean[]> createTable(){
        HashMap<String,boolean[]> map=new HashMap();
        map.put("Пн", new boolean[24]);
        map.put("Вт", new boolean[24]);
        map.put("Ср", new boolean[24]);
        map.put("Чт", new boolean[24]);
        map.put("Пт", new boolean[24]);
        map.put("Сб", new boolean[24]);
        map.put("Вс", new boolean[24]);
        //map.get("Вт")[2]=true;
        return map;
    }
}
class DrawTable extends JPanel{
    Table table;
    HashMap<String, LabelPanel> rows;
    LabelPanel[] cols;
    public DrawTable(Table table){
        this.table=table;
        this.setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));       
        //this.setPreferredSize(new Dimension(BtnPanel.btnWidth*24,BtnPanel.btnHeight*7+10));                   
        this.add(makeTitle());
        rows=new HashMap(); 
        cols=new LabelPanel[24];    
        for(int i=0;i<7;i++){
            JPanel pHor=new JPanel();
            pHor.setLayout(new BoxLayout(pHor,BoxLayout.X_AXIS));                    
            pHor.setAlignmentX(LEFT_ALIGNMENT);
            String day="";
            switch(i){
                case 0:{day="Пн";break;}
                case 1:{day="Вт";break;}
                case 2:{day="Ср";break;}
                case 3:{day="Чт";break;}
                case 4:{day="Пт";break;}
                case 5:{day="Сб";break;}
                case 6:{day="Вс";break;}
            }
            rows.put(day, new LabelPanel(day));
            pHor.add(rows.get(day));
            for(int j=0;j<24;j++){
                pHor.add(new BtnPanel(day,j,this.table.table,rows,cols));
                pHor.add(Box.createRigidArea(new Dimension(1,0)));
            }                        
            this.add(pHor);
            this.add(Box.createRigidArea(new Dimension(0,1)));            
        }
        JPanel pHor=new JPanel();
        pHor.setLayout(new BoxLayout(pHor,BoxLayout.X_AXIS));                    
        pHor.setAlignmentX(LEFT_ALIGNMENT);
        pHor.add(new LabelPanel(""));                    
        for(int i=0;i<24;i++){
            cols[i]=new LabelPanel(" "+i);
            pHor.add(cols[i]);
            pHor.add(Box.createRigidArea(new Dimension(1,0)));
        }
        this.add(pHor);
        //this.add(title);
        this.add(Box.createVerticalGlue());
    }   
    JPanel makeTitle(){
        JPanel title=new JPanel();
        title.setAlignmentX(LEFT_ALIGNMENT);
        title.setLayout(new BoxLayout(title,BoxLayout.Y_AXIS));  
        
        JPanel hor=new JPanel();        
        hor.setLayout(new BoxLayout(hor,BoxLayout.X_AXIS));  
        
        JLabel name=new JLabel(this.table.tableName);
        name.setFont(new Font("Arial",Font.BOLD,20));
        
        JTextField login=new JTextField(this.table.login);
        login.addCaretListener(new javax.swing.event.CaretListener() {
            public void caretUpdate(javax.swing.event.CaretEvent evt) {
                DrawTable.this.table.login=login.getText();
                //System.out.println(DrawTable.this.table.login);
            }
        });
        login.setPreferredSize(new Dimension(150, 20));
        login.setMaximumSize(new Dimension(150, 20));
        login.setMinimumSize(new Dimension(150, 20));
        login.setFont(new Font("Arial",Font.PLAIN,14));
        
        JTextField password=new JTextField(this.table.password);
        password.setPreferredSize(new Dimension(150, 20));
        password.setMaximumSize(new Dimension(150, 20));
        password.setMinimumSize(new Dimension(150, 20));
        password.setFont(new Font("Arial",Font.PLAIN,14));
        
        hor.add(Box.createRigidArea(new Dimension(50,0)));
        hor.add(name);
        hor.add(Box.createRigidArea(new Dimension(50,0)));
        hor.add(login);
        hor.add(Box.createRigidArea(new Dimension(10,0)));
        hor.add(password);
        title.add(Box.createRigidArea(new Dimension(0,10)));
        title.add(hor);
        title.add(Box.createRigidArea(new Dimension(0,5)));
        return title;
    }
}
class BtnPanel extends JPanel{
    public String day;
    public int time;
    public boolean status;
    public JButton btn;
    public static int btnWidth=25;
    public static int btnHeight=25;
    private HashMap<String, boolean[]> table;
    private HashMap<String, LabelPanel> rows;
    private LabelPanel[] cols;
    public BtnPanel(String day, int time, HashMap table, HashMap rows, LabelPanel[] cols){
        //super("-");        
        this.day=day;        
        this.time=time;
        this.table=table;
        this.rows=rows;
        this.cols=cols;
        this.status=this.table.get(day)[time];        
        this.setLayout(null); 
        this.setMinimumSize(new Dimension(btnWidth,btnHeight));
        this.setMaximumSize(new Dimension(btnWidth,btnHeight));
        this.setPreferredSize(new Dimension(btnWidth,btnHeight));
        this.setSize(new Dimension(btnWidth,btnHeight));
        //this.setAlignmentX(LEFT_ALIGNMENT);
        setBtnParam();    
        updateStatus();
        this.add(btn);       
       
    }    
    private void setBtnParam(){
        btn=new JButton();
        btn.setText("-");
        btn.setLocation(0,0);
        btn.setSize(btnWidth,btnHeight);        
        Border bord = new LineBorder(Color.BLACK, 1);
        btn.setFont(new Font("Arial",Font.PLAIN,20));
        btn.setFocusable(false);
        btn.setBorder(bord);  
        //btn.setAlignmentX(LEFT_ALIGNMENT);
        btn.addMouseListener(new MouseAdapter(){
            public void mouseEntered(MouseEvent e){                                
                rows.get(day).setBackground(new Color(250,250,10));
                cols[time].setBackground(new Color(250,250,10));
            }
            public void mouseExited(MouseEvent e){                                
                //System.out.println("clicked");
                rows.get(day).setBackground(null);
                cols[time].setBackground(null);
            }
            public void mousePressed(MouseEvent e){
                //System.out.println("clicked");
                if(BtnPanel.this.status){  
                    BtnPanel.this.status=false;
                    BtnPanel.this.btn.setText("-");
                    BtnPanel.this.btn.setBackground(null);
                    BtnPanel.this.table.get(BtnPanel.this.day)[BtnPanel.this.time]=false;                    
                }else{
                    BtnPanel.this.status=true;
                    BtnPanel.this.btn.setText("+");
                    BtnPanel.this.btn.setBackground(new Color(100,200,100));
                    BtnPanel.this.table.get(BtnPanel.this.day)[BtnPanel.this.time]=true;                    
                }                             
                for (Map.Entry<String, boolean[]> entry : BtnPanel.this.table.entrySet()) {
                    boolean[] temp = entry.getValue();
                    System.out.print(entry.getKey()+" ");
                    for(int i=0;i<temp.length;i++){
                        System.out.print(temp[i]+" ");
                    }
                    System.out.println();                    
                } 
                System.out.println();
                
                try {
                    LotsUpdater.saveTables();
                    //updateStatus();
                } catch (IOException ex) {
                    Logger.getLogger(BtnPanel.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }
    private void updateStatus(){
        if(status){
            BtnPanel.this.btn.setText("+");
            BtnPanel.this.btn.setBackground(new Color(100,200,100));
        }else{
            BtnPanel.this.btn.setText("-");
            BtnPanel.this.btn.setBackground(null);
        }
    }
}
class LabelPanel extends JPanel{
    public JLabel label;
    public static int labelWidth=25;
    public static int labelHeight=25;
    public LabelPanel(String name){
        this.setLayout(null); 
        this.setMinimumSize(new Dimension(labelWidth,labelHeight));
        this.setMaximumSize(new Dimension(labelWidth,labelHeight));
        this.setPreferredSize(new Dimension(labelWidth,labelHeight));
        //this.setSize(new Dimension(btnWidth,btnHeight));
        //this.setAlignmentX(LEFT_ALIGNMENT);        
        label=new JLabel(name);
        setLabelParam();
        this.add(label); 
    }
    void setLabelParam(){                
        label.setLocation(0,0);
        label.setSize(labelWidth,labelHeight);        
        //Border bord = new LineBorder(Color.BLACK, 1);
        label.setFont(new Font("Arial",Font.PLAIN,14));
        //btn.setFocusable(false);
        //btn.setBorder(bord);  
    }
}
class Settings implements Serializable{
    boolean isAutorun=false;  
    boolean isRunnued=false;
    boolean isWindowVisible=true;
    int consumersCount=3;
    //String currProjPath=System.getProperty("user.dir");
    String status="status:    жду запуска...";
    public void saveSettings(){
        FileOutputStream fos;
        try {
            fos = new FileOutputStream(LotsUpdater.currProjPath+"\\Settings\\settings.out");            
            ObjectOutputStream oos = new ObjectOutputStream(fos);            
            oos.writeObject(this);
            oos.flush();
            oos.close();
            fos.close();
        } catch (Exception ex) {
            Logger.getLogger(Settings.class.getName()).log(Level.SEVERE, null, ex);
        }        
        //TestSerial ts = new TestSerial();                
    }
    public static Settings loadSettings(){                
        FileInputStream fis=null;
        ObjectInputStream oin=null;
        Settings setting=null;
        try {
            fis = new FileInputStream(LotsUpdater.currProjPath+"\\Settings\\settings.out");
            oin = new ObjectInputStream(fis);            
            setting=(Settings) oin.readObject();            
            fis.close();
            oin.close();
        } catch (Exception ex) {
            Logger.getLogger(Settings.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            try {
                fis.close();
                oin.close();
            } catch (IOException ex) {
                Logger.getLogger(Settings.class.getName()).log(Level.SEVERE, null, ex);
            }            
        }    
        if(!setting.isRunnued){
            setting.status="status:    жду запуска...";
        }
        return setting;
    }
    public void settingsChanged(){
        MenuFrame.updateMenu(this);
    }
}