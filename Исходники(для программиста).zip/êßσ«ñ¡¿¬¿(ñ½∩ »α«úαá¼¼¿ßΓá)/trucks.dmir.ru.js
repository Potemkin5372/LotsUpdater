"use strict";
var page = require('webpage').create();
var system = require('system');   
var inProgress=false;
var login=system.args[1];
var password=system.args[2];
var log_json=JSON.stringify(login+" "+password);
var isLogined=false;
var isLotsOpened=false;
var countOfLogingTryes=0;
var countOfOpenPageTryes=0;
page.onConsoleMessage = function(msg) {
  console.log(msg);
}
page.onLoadStarted = function() {
  inProgress = true;
  //exeFuncCount++;
  console.log("started...");  
};

page.onLoadFinished = function() {
  inProgress = false;
  //exeFuncCount--;
  console.log("finished...");
};
page.injectJs('jquery.js');

setInterval(function(){
	if(!isLogined){
		if(countOfLogingTryes<15){
			page.open('http://trucks.dmir.ru/'+'?'+encodeURIComponent(log_json), function(status2) {
				if(status2==="success"){
					isLogined=true;
					page.evaluate(function(){
						$('#btnLogInUser').click();
						var log_json=decodeURIComponent(window.location.search.substring(1));
				    	var str=eval('('+log_json+')');
				    	var login=str.substring(0,str.indexOf(" "));
				    	var password=str.substring(str.indexOf(" ")+1,str.length);
						$('#txtEmail').val(login);
						$('#txtPassword').val(password);
						$('.ui-button.ui-widget.ui-state-default.ui-corner-all.ui-button-text-only').click();
					});					
					setInterval(function(){
				    	if(!inProgress){
				    		if(!isLotsOpened){
				    			if(countOfOpenPageTryes<15){
				    				page.open('http://trucks.dmir.ru/user/offers/',function(status){
					    				if(status==="success"){
					    					isLotsOpened=true;
					    					console.log("страница открыта");
					    					page.evaluate(function(){
					    						$('#updateOffersDate').click();
					    					});
					    					setTimeout(function(){
					    						//page.render('N:/Tasks//Задание3//newSite.png');
												console.log("0");
												phantom.exit();	
					    					},5000);					    					
					    				}else{
					    					countOfOpenPageTryes++;
					    				}
					    			});
				    			}else{
				    				console.log("3");
									phantom.exit();	
				    			}
				    		}				    						    		
				    	}
				    },2500);					   	   	
				}else{
					console.log("Can't login");
					countOfLogingTryes++;
				}
			});
		}else{
			//page.render(pathForScreen);
			console.log("1");
			phantom.exit();		    	   
		}
	}
},5000);