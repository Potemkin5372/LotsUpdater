"use strict";
var inProgress=false;
var isLotsOpened=false;
var externCurrElemIndex=0;
var externElems = new Array();
var externUpdateLeft = new Array();
var externUpdateLeftForPrevLot;
var page = require('webpage').create();
var system = require('system');   
//window.logi=system.args[1];
var login=system.args[1];
var password=system.args[2];
var log_json=JSON.stringify(login+" "+password);
var notAllWasUpdated=false;
//var pass_json=JSON.stringify(password);
//page.evaluate("function() {document.body.innerHTML = '" + size + uid + "'}");

//var page = require('webpage').create();
var testUpdate=0;	
var isLogined=false;
var countOfLogingTryes=0;
var countOfOpenPageTryes=0;
var countOfUpdatingTryes=0;
var isGatherStady=true;
var externCurrPage=2;
var externTotalPageCount=0;
page.onConsoleMessage = function(msg) {
  console.log(msg);
}
page.onLoadStarted = function() {
  inProgress = true;
  //exeFuncCount++;
  console.log("started...");  
};

page.onLoadFinished = function() {
  inProgress = false;
  //exeFuncCount--;
  console.log("finished...");
};
page.injectJs('jquery.js');

setInterval(function(){
	if(!isLogined){
		if(countOfLogingTryes<15){
			console.log(encodeURIComponent(log_json));
			page.open('http://access.acoola.ru/'+'?'+encodeURIComponent(log_json), function(status2) {
			//page.includeJs("http://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js", function() {		
				if(status2==="success"){
					//page.injectJs('incl.js');						
					isLogined=true;
				    page.evaluate(function() {						    			    
				    	var log_json=decodeURIComponent(window.location.search.substring(1));
				    	var str=eval('('+log_json+')');
				    	var login=str.substring(0,str.indexOf(" "));
				    	var password=str.substring(str.indexOf(" ")+1,str.length);
				    	//console.log(login+"    "+password);				    	
				    	$("#id_username").val(login)
				       //$("#username").text("infoboss@yandex.ru");
			       		$("#id_password").val(password);
			       		//page.render('N:/Tasks//Задание3//screen.png');			
			       		//$("form[action='.']").submit();         		     	
			       		$("#submit_button").click();			       		
			       		//setTimeout(function(){

				       	//document.location = "http://exkavator.ru/trade/companymanager/show_lots.html"	              		
				    });	
				    /*setTimeout(function(){
						page.render('N:/Tasks//Задание3//newSite.png');
						console.log("Screen saved");
						phantom.exit();	
					},3000);*/
					setInterval(function(){
				    	if(!inProgress){	
				    		if(!isLotsOpened){			    		
					    		if(countOfOpenPageTryes<15){
					    			//var postBody= 'page=4';
						    		page.open('http://www.acoola.ru/ann/active', function(status){
						    			if(status==="success"){
						    				console.log("страница открыта");						    				
						    				isLotsOpened=true;
						    				/*page.render('N:/Tasks//Задание3//newSite.png');
											console.log("Screen saved");
											phantom.exit();		*/
						    				//TO DO
						    				//Собрать индексы объявлений
						    				//подгрузить все объявления
						    				externTotalPageCount=page.evaluate(function(){
						    					window.currPage=2;
						    					return Number($('#li-check-active span')[0].innerHTML);
						    					//select_page_add(2, '/ann/active', 'ann-list-block', true);	
						    					//select_page_add(3, '/ann/active', 'ann-list-block', true);	
						    				});
						    				externTotalPageCount=Math.ceil(externTotalPageCount/20);
						    				//console.log(externTotalPageCount);	
						    				var delay=1000;
						    				setTimeout(function tick(){
						    					if(isGatherStady){						    						
						    						if(externCurrPage<=externTotalPageCount){
														externCurrPage=page.evaluate(function(){
							    							//console.log(window.currPage);
							    							select_page_add(window.currPage, '/ann/active', 'ann-list-block', true);	
							    							window.currPage++;
							    							return window.currPage;
							    						});
							    					}else{
							    						delay=2500;													    										    						    					
							    						externElems=page.evaluate(function() {		
							    							window.currElemIndex=0;  								    							
								    						window.elems = new Array();  
								    						//console.log($('body').scrollTop(1000));				    															    								    												    					
															$(".item").each(function () {
																window.elems.push(this.id);									
																//console.log(this.id);
															});																
															return window.elems;			    					    					
									    				});
									    				isGatherStady=false;							    						
							    					}
						    					}else{
						    						if(externCurrElemIndex<externElems.length){
						    							//UPDATE IS HERE!						    							
						    							console.log('http://www.acoola.ru/ann/up/'+externElems[externCurrElemIndex].substring(5));
						    							page.open('http://www.acoola.ru/ann/up/'+externElems[externCurrElemIndex].substring(5),function(status3){});						    								
						    							externCurrElemIndex++;
						    							/*externCurrElemIndex=page.evaluate(function(){						    								
						    								if(window.testUpdate<2){
						    									console.log('#href-up-ann-'+window.elems[window.currElemIndex].substring(5));
						    									$('#href-up-ann-'+window.elems[window.currElemIndex].substring(5)).click();
						    									window.testUpdate++;
						    								}
						    								//console.log(window.elems[window.currElemIndex]);
						    								currElemIndex++;
						    								return window.currElemIndex;
						    							});*/
														
						    							//console.log(delay);
						    						}else{
						    							//page.render('N:/Tasks//Задание3//newSite.png');
						    							console.log('0');
							    						phantom.exit();
						    						}						    						
						    					}	
						    					setTimeout(tick,delay);					    					
						    				},delay);
						    										    				
						    			}else{
						    				countOfOpenPageTryes++;
						    				console.log("не могу открыть страницу...");
						    			}
						    		});
						    	}else{	
						    		console.log("3");
									phantom.exit();	
								}
							}
						}
					},2500);	
				}else{
					console.log("Can't login");
					countOfLogingTryes++;
				} 	
			});
		}else{
			//page.render(pathForScreen);
			console.log("1");
			phantom.exit();		    	   
		}
	}
},5000);
