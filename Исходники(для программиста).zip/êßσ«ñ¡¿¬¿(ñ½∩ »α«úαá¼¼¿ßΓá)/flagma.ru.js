"use strict";
var page = require('webpage').create();
var system = require('system');  
var login=system.args[1];
var password=system.args[2];
var log_json=JSON.stringify(login+" "+password);
var isLogined=false;
var countOfLogingTryes=0;
var inProgress=false;
var isLotsOpened=false;
var countOfOpenPageTryes=0;
var nextPage='http://moscow.flagma.ru/my/349295/obyavleniya.html';
page.onConsoleMessage = function(msg) {
  console.log(msg);
}
page.onLoadStarted = function() {
  inProgress = true;
  //exeFuncCount++;
  console.log("started...");  
};

page.onLoadFinished = function() {
  inProgress = false;
  //exeFuncCount--;
  console.log("finished...");
};
page.injectJs('jquery.js');
setInterval(function(){
	if(!isLogined){
		if(countOfLogingTryes<15){
			console.log("I'am try to login...");
			page.open('http://flagma.ru/login'+'?'+encodeURIComponent(log_json), function(status2) {
				if(status2==="success"){
					isLogined=true;
					page.evaluate(function(){						
						var log_json=decodeURIComponent(window.location.search.substring(1));						
				    	var str=eval('('+log_json+')');
				    	var login=str.substring(0,str.indexOf(" "));
				    	var password=str.substring(str.indexOf(" ")+1,str.length);				    	
						$('#LoginForm_username').val(login);
						$('#LoginForm_password').val(password);
						$('#login_button_main').click();
					});	
					/*setTimeout(function(){
						page.render('N:/Tasks//Задание3//newSite.png');
						console.log("Screen saved");
						phantom.exit();	
					},2500);*/
				}
			});
			setInterval(function(){
				if(!inProgress){
					if(nextPage!=null){
				    	if(countOfOpenPageTryes<15){
				    		page.open(nextPage,function(status){
					    		if(status==="success"){					    			
					    			console.log("страница "+nextPage+" открыта");					    			
					    			nextPage=page.evaluate(function() {						    					  					    									    			
					    				window.confirm = function(msg){
					    					console.log("confirmed");					    			
										    return true; // will "close the alert"
										};
					    				$('.check-all').click();					    				
					    				//$('.update-messages').click();								    				
					    				$('[value="Обновить"]')[0].click();
					    				return $('.next a').attr("href");
						    		});		
						    		/*setTimeout(function(){	
							    		page.render('N:/Tasks//Задание3//newSite.png');
										console.log("Screen saved");
										phantom.exit();		
									},2000);*/						    		    	
					    			countOfOpenPageTryes=0;					    								    							    				
					    		}else{
					    			countOfOpenPageTryes++;
					    		}
					    	});
				    	}else{
				    		console.log("3");
							phantom.exit();	
			    		}
					}
					else{						
						console.log("0");	
						phantom.exit();
					}				    						    		
				}
			},3000);	
		}else{
			//page.render(pathForScreen);
			console.log("1");
			phantom.exit();		    	   
		}
	}
},5000);